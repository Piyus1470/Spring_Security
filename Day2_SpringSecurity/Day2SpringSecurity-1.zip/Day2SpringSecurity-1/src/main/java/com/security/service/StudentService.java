package com.security.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.security.entity.Student;

@Service
public class StudentService {

    public List<Student> students = new ArrayList<>(
    		List.of(
    				   new Student(101, "Piyush"),
    			       new Student(102, "Lucky"),
    			       new Student(103, "Jitu")
    				)
    		);
    
    
    public List<Student> getAll()
    {
    	return students;
    }


	public Student saveStudent(Student std) {
		students.add(std);
		return std;
		
	}
}
