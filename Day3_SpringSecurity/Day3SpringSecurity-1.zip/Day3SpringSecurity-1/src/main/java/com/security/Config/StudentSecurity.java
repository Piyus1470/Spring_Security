package com.security.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class StudentSecurity {

	@Autowired
	private StudentUserdtls stdStudentUserdtls;
	
	@Bean
	SecurityFilterChain func1(HttpSecurity http) throws Exception
	{
		return http.csrf(csrf -> csrf.disable())
				   .authorizeHttpRequests(req -> req.requestMatchers("/save").permitAll()
				   .anyRequest().authenticated())
				   .httpBasic(Customizer.withDefaults())
				   .build();
	}
	
	
	  @Bean 
	  AuthenticationProvider func2() { 
		  DaoAuthenticationProvider
	  daoAuthenticationProvider = new DaoAuthenticationProvider();
	  daoAuthenticationProvider.setPasswordEncoder(func3());
	  daoAuthenticationProvider.setUserDetailsService(stdStudentUserdtls); 
	  return daoAuthenticationProvider; 
	  }
	 
	
	@Bean
    PasswordEncoder func3()
	{
		return new BCryptPasswordEncoder();
	}
}
