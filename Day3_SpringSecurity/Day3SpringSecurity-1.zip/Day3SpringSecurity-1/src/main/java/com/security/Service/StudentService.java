package com.security.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.security.Entity.Student;
import com.security.Repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	public Student save(Student std)
	{
		String pass = passwordEncoder.encode(std.getPassword());
		std.setPassword(pass);
		studentRepository.save(std);
		return std;
	}
	
	public List<Student> getAll()
	{
		return studentRepository.findAll();
	}
}
