package com.security.Config;


import java.util.Collections;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.security.Entity.Student;
import com.security.Repository.StudentRepository;

@Service
public class StudentUserdtls implements UserDetailsService {

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Student std = studentRepository.findByName(username);
		if(std==null)
		{
			throw new NoSuchElementException("user not found");
		}
		
		return new User(std.getName(),std.getPassword(),Collections.singleton(new SimpleGrantedAuthority(std.getRole())));
	}

}
