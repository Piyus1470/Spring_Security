package com.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Day3SpringSecurity1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day2SpringSecurity2Application.class, args);
		}
	}

