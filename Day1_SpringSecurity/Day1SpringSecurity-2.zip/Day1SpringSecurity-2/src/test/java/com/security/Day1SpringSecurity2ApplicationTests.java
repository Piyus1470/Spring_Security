package com.security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1SpringSecurity2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
