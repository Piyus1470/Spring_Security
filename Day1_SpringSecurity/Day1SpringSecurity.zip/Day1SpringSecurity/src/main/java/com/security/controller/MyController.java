package com.security.controller;

import java.net.http.HttpRequest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;

@RestController
public class MyController {

	@GetMapping("/")
	public String fun(HttpServletRequest req)
	{
		return "ram_ji"+req.getSession().getId();
	}
}
